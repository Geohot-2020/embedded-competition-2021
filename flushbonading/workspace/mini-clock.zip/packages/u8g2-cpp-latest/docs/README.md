![u8g2 logo](u8g2_logo.png)
# rt-u8g2

## 使用说明

- 移植请参照 : [移植方法](../port/README.md)
- 例程请参照 : [ssd1306 液晶 与 YL-40 模块](../examples/README.md)
- API 请参照 : [U8g2 Reference](https://github.com/olikraus/u8g2/wiki/u8g2reference)


## Todo list

[●] Hardware I2C  
[●] Hardware SPI  
[●] Software I2C  
[●] Software SPI  
[●] 8080 & 6800  
