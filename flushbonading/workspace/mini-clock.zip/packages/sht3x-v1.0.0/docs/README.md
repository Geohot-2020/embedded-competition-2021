# 文档

## 软件包地址

- https://github.com/donghao2nanjing/sht3x

## 文档列表

|文件名                             |描述|
|:-----                             |:----|
|[version.md](version.md)           |版本信息|
|[api.md](api.md)                   |API 说明|

