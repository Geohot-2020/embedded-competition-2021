#ifndef JS_COMMON_H__
#define JS_COMMON_H__

void js_do_result(jerry_value_t object, jerry_value_t res, int result);

#endif
